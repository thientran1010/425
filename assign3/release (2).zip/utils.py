from skimage import io
from skimage.util import img_as_float
from skimage.color import rgb2gray
import numpy as np
from scipy.ndimage import correlate
import sklearn.cluster
from scipy.spatial.distance import cdist

def computeHistogram(img_file, F, textons):
    
    ### YOUR CODE HERE

    ### END YOUR CODE
    
def createTextons(F, file_list, K):

    ### YOUR CODE HERE

    ### END YOUR CODE
